import React from 'react'

const Section = ({content}) => {
  return (
    <div className=''>
        {content}
    
    </div>
  )
}

export default Section